package com.example.educationsystemproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EducationSystemProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(EducationSystemProjectApplication.class, args);
    }

}
