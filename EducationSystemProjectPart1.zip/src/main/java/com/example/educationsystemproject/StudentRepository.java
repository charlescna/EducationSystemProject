package com.example.educationsystemproject;

import org.springframework.data.repository.CrudRepository;

// import com.example.educationsystemproject.Student;

public interface StudentRepository extends CrudRepository<Student, Integer> {

}
